document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-year]").forEach(el => el.textContent = new Date().getFullYear());

  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");
  if (menuButton && nav) {
    menuButton.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(open));
    });
  }

  const filterButtons = [...document.querySelectorAll("[data-filter]")];
  const cards = [...document.querySelectorAll("[data-category]")];
  filterButtons.forEach(button => button.addEventListener("click", () => {
    filterButtons.forEach(b => b.classList.toggle("active", b === button));
    cards.forEach(card => card.hidden = button.dataset.filter !== "all" && card.dataset.category !== button.dataset.filter);
  }));

  const config = window.GOLDEN_INK_CONFIG || {};
  const endpoint = typeof config.formspreeEndpoint === "string" ? config.formspreeEndpoint.trim() : "";
  const endpointReady = /^https:\/\/formspree\.io\/f\/[A-Za-z0-9]+$/.test(endpoint);
  const setStatus = (form, message) => {
    const status = form.querySelector(".form-status");
    if (status) status.textContent = message;
  };
  const postForm = async (form, payload) => {
    if (!endpointReady) {
      setStatus(form, "Live delivery is not configured yet. Create a Formspree form, paste its real endpoint into config.js, then test before launch. For now, email Bensonbett001@gmail.com directly.");
      return false;
    }
    const submit = form.querySelector('[type="submit"]');
    if (submit) { submit.disabled = true; submit.dataset.originalText = submit.textContent; submit.textContent = "Sending…"; }
    try {
      const body = new FormData();
      Object.entries(payload).forEach(([key, value]) => body.append(key, value == null ? "" : String(value)));
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Accept": "application/json" },
        body
      });
      let result = {};
      try { result = await response.json(); } catch (_) {}
      if (!response.ok) throw new Error((result.errors || []).map(e => e.message).join(" ") || "The form service did not accept the request.");
      return true;
    } catch (error) {
      setStatus(form, "We could not confirm delivery. Please email Bensonbett001@gmail.com directly. Details: " + (error.message || "network error"));
      return false;
    } finally {
      if (submit) { submit.disabled = false; submit.textContent = submit.dataset.originalText || "Submit"; }
    }
  };

  const designSelect = document.querySelector("#design");
  if (designSelect) {
    const chosen = new URLSearchParams(location.search).get("design");
    if (chosen && [...designSelect.options].some(option => option.value === chosen)) designSelect.value = chosen;
    const dateInput = document.querySelector('input[name="date"]');
    if (dateInput) dateInput.min = new Date().toISOString().slice(0, 10);
    try {
      const saved = JSON.parse(sessionStorage.getItem("goldenInkBookingRequest") || "{}");
      for (const [key, value] of Object.entries(saved)) {
        const field = document.querySelector(`[name="${CSS.escape(key)}"]`);
        if (field && field.type !== "checkbox" && field.type !== "radio") field.value = value;
        if (field && field.type === "checkbox") field.checked = value === "on" || value === true;
      }
    } catch (_) {}
  }

  const bookingForm = document.querySelector("#bookingForm");
  if (bookingForm) bookingForm.addEventListener("submit", event => {
    event.preventDefault();
    if (!bookingForm.reportValidity()) return;
    const data = Object.fromEntries(new FormData(bookingForm).entries());
    try { sessionStorage.setItem("goldenInkBookingRequest", JSON.stringify(data)); } catch (_) {}
    window.location.href = "artists.html";
  });

  const artistForm = document.querySelector("#artistForm");
  if (artistForm) artistForm.addEventListener("submit", async event => {
    event.preventDefault();
    if (!artistForm.reportValidity()) return;
    let booking = {};
    try { booking = JSON.parse(sessionStorage.getItem("goldenInkBookingRequest") || "{}"); } catch (_) {}
    if (!booking.name || !booking.email || !booking.date || !booking.design) {
      setStatus(artistForm, "Your request details were not found in this browser. Please return to the booking form and complete it again.");
      return;
    }
    booking.artistPreference = new FormData(artistForm).get("artist");
    booking._subject = "Golden Ink appointment request — " + booking.name;
    booking._replyto = booking.email;
    booking._gotcha = "";
    booking.notificationPreference = "Email only";
    booking.calendarWorkflow = "Manual studio approval; add to Google Calendar after confirmation";
    const sent = await postForm(artistForm, booking);
    if (!sent) return;
    try { sessionStorage.setItem("goldenInkBookingRequest", JSON.stringify(booking)); } catch (_) {}
    setStatus(artistForm, "Request submitted to the form service. This is not an appointment confirmation. The studio must review your request and email you before you pay a deposit.");
    const next = document.querySelector("#bookingNextStep");
    if (next) {
      next.hidden = false;
      next.innerHTML = 'Next: wait for confirmation at your email address. After the studio confirms your date and deposit, you can open the <a class="text-link" href="payment.html">PayPal deposit options</a>.';
    }
    const submit = artistForm.querySelector('[type="submit"]');
    if (submit) submit.disabled = true;
  });

  document.querySelectorAll("[data-live-contact]").forEach(form => form.addEventListener("submit", async event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const payload = Object.fromEntries(new FormData(form).entries());
    payload._subject = "Golden Ink website inquiry — " + (payload.name || "New inquiry");
    payload._replyto = payload.email || "";
    payload._gotcha = "";
    const sent = await postForm(form, payload);
    if (sent) {
      setStatus(form, "Inquiry submitted to the form service. If you do not receive a reply, contact Bensonbett001@gmail.com directly.");
      form.reset();
    }
  }));
});
