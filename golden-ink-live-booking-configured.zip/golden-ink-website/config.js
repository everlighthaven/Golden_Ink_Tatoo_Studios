/* Golden Ink integrations configuration.
   Paste the real Formspree endpoint from your account after creating the form.
   Example format: https://formspree.io/f/xxxxxxxx
   Do not put passwords, API secrets, or Google OAuth credentials in this file.
*/
window.GOLDEN_INK_CONFIG = {
  formspreeEndpoint: "https://formspree.io/f/xzeeevvr", // Supplied by studio owner; delivery still requires testing
  studioNotificationEmail: "Bensonbett001@gmail.com"
};
