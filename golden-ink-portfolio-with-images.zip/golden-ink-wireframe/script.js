document.addEventListener('DOMContentLoaded', () => {
  // Portfolio filters
  const filters = document.querySelectorAll('[data-filter]');
  const cards = document.querySelectorAll('.design-card');
  filters.forEach(button => button.addEventListener('click', () => {
    filters.forEach(item => item.classList.remove('active'));
    button.classList.add('active');
    const value = button.dataset.filter;
    cards.forEach(card => card.hidden = !(value === 'all' || card.dataset.style === value));
  }));

  // Booking page: select a portfolio design via query string and display its sample price.
  const designSelect = document.getElementById('design');
  const selectedPrice = document.getElementById('selectedPrice');
  if (designSelect && selectedPrice) {
    const params = new URLSearchParams(window.location.search);
    const design = params.get('design');
    if (design && [...designSelect.options].some(option => option.value === design)) designSelect.value = design;
    const updatePrice = () => {
      const option = designSelect.options[designSelect.selectedIndex];
      selectedPrice.textContent = option && option.dataset.price ? `$${option.dataset.price}* sample` : 'Quote required';
    };
    designSelect.addEventListener('change', updatePrice);
    updatePrice();
    const form = document.getElementById('bookingForm');
    form?.addEventListener('submit', event => {
      event.preventDefault();
      const value = designSelect.value;
      if (!value) return;
      sessionStorage.setItem('goldenInkDesign', value);
      sessionStorage.setItem('goldenInkDesignLabel', designSelect.options[designSelect.selectedIndex].text);
      alert('Prototype: design selection noted for this browser session. Next, choose an artist. Booking details are not yet saved to a server.');
      window.location.href = 'artists.html';
    });
  }

  // Artist selection prototype
  document.querySelectorAll('[data-artist]').forEach(button => button.addEventListener('click', () => {
    sessionStorage.setItem('goldenInkArtist', button.dataset.artist);
    const label = document.getElementById('artistSelection');
    if (label) label.textContent = button.dataset.artist;
    document.querySelectorAll('[data-artist]').forEach(item => {
      item.classList.remove('gold');
      item.classList.add('outline');
      item.textContent = 'Select artist';
    });
    button.classList.remove('outline');
    button.classList.add('gold');
    button.textContent = 'Selected';
  }));
});