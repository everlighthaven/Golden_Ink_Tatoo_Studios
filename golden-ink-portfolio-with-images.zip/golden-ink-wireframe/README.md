# Golden Ink Tattoo Studio — Frontend Wireframe

This is a responsive, clickable frontend wireframe for the seven-step site plan:
1. Frontend wireframe
2. Homepage / landing page
3. Contacts
4. Portfolio
5. Booking
6. Select artist
7. Payment

## Preview locally
Open `index.html` in a browser. All pages link to each other.

## Important before launch
- Replace all placeholder contact, address, artist, availability, and artwork details with verified information.
- The portfolio prices are illustrative placeholders only. Match each tattoo to the exact row in the approved price list before publishing.
- PayPal deposit links are wired into `payment.html`, but verify the displayed amount and currency for each PayPal link.
- The booking and contact forms are prototypes and do not send or store data.
- Artist and design selection is a browser-session prototype; no database or live calendar is connected.
- Do not add secret API keys to frontend files.
- The portfolio now includes five cropped AI-generated concept-model images for preview. They are not real or verified clients and must not be represented as completed studio work. Replace them with real, permissioned studio tattoo photos before launch.

## Files
- `index.html`: homepage
- `contacts.html`: contact page
- `portfolio.html`: filtered portfolio gallery with per-design price rows
- `booking.html`: booking details form
- `artists.html`: artist selection
- `payment.html`: PayPal deposit choices
- `styles.css`: responsive black-and-gold styling
- `script.js`: gallery filters and prototype selection interactions
